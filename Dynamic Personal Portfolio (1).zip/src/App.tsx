import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Skills } from './components/Skills';
import { Projects } from './components/Projects';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { Toaster } from './components/ui/sonner';

// Portfolio data - easily customizable
const portfolioData = {
  name: 'John Doe',
  title: 'Full Stack Developer',
  description:
    'Passionate about creating beautiful and functional web applications. I specialize in modern web technologies and love bringing ideas to life through code.',
  socialLinks: {
    github: 'https://github.com',
    linkedin: 'https://linkedin.com',
    email: 'john.doe@example.com',
  },
  about: {
    image: 'https://images.unsplash.com/photo-1621743018966-29194999d736?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjB3b3Jrc3BhY2UlMjBkZXNrfGVufDF8fHx8MTc2Mjc0MDYxNnww&ixlib=rb-4.1.0&q=80&w=1080',
    bio: [
      "I'm a passionate full stack developer with a love for creating elegant solutions to complex problems. With several years of experience in web development, I've worked on a variety of projects ranging from small business websites to large-scale applications.",
      "When I'm not coding, you can find me exploring new technologies, contributing to open-source projects, or sharing my knowledge through blog posts and mentoring. I believe in continuous learning and staying up-to-date with the latest industry trends.",
      "My goal is to build applications that not only look great but also provide exceptional user experiences and solve real-world problems.",
    ],
  },
  skillCategories: [
    {
      category: 'Frontend',
      skills: ['React', 'TypeScript', 'Next.js', 'Tailwind CSS', 'HTML/CSS'],
    },
    {
      category: 'Backend',
      skills: ['Node.js', 'Express', 'Python', 'PostgreSQL', 'MongoDB'],
    },
    {
      category: 'Tools & Others',
      skills: ['Git', 'Docker', 'AWS', 'Figma', 'CI/CD'],
    },
  ],
  projects: [
    {
      title: 'E-commerce Platform',
      description: 'A full-featured online store with payment integration and admin dashboard.',
      image: 'https://images.unsplash.com/photo-1557821552-17105176677c?w=800',
      technologies: ['React', 'Node.js', 'Stripe', 'MongoDB'],
      liveUrl: 'https://example.com',
      githubUrl: 'https://github.com',
    },
    {
      title: 'Task Management App',
      description: 'Collaborative task manager with real-time updates and team features.',
      image: 'https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?w=800',
      technologies: ['Next.js', 'TypeScript', 'Prisma', 'PostgreSQL'],
      liveUrl: 'https://example.com',
      githubUrl: 'https://github.com',
    },
    {
      title: 'Weather Dashboard',
      description: 'Real-time weather information with beautiful data visualizations.',
      image: 'https://images.unsplash.com/photo-1592210454359-9043f067919b?w=800',
      technologies: ['React', 'Chart.js', 'Weather API', 'Tailwind'],
      liveUrl: 'https://example.com',
      githubUrl: 'https://github.com',
    },
    {
      title: 'Portfolio Generator',
      description: 'Tool to help developers create stunning portfolios quickly.',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800',
      technologies: ['React', 'Node.js', 'Express', 'MongoDB'],
      liveUrl: 'https://example.com',
      githubUrl: 'https://github.com',
    },
    {
      title: 'Fitness Tracker',
      description: 'Track workouts, nutrition, and progress with detailed analytics.',
      image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800',
      technologies: ['React Native', 'Firebase', 'Redux', 'Charts'],
      liveUrl: 'https://example.com',
      githubUrl: 'https://github.com',
    },
    {
      title: 'Blog Platform',
      description: 'Modern blogging platform with markdown support and SEO optimization.',
      image: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=800',
      technologies: ['Next.js', 'MDX', 'Vercel', 'TypeScript'],
      liveUrl: 'https://example.com',
      githubUrl: 'https://github.com',
    },
  ],
  contactInfo: {
    email: 'john.doe@example.com',
    phone: '+1 (555) 123-4567',
    location: 'San Francisco, CA',
  },
};

export default function App() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <Hero
        name={portfolioData.name}
        title={portfolioData.title}
        description={portfolioData.description}
        socialLinks={portfolioData.socialLinks}
      />
      <About image={portfolioData.about.image} bio={portfolioData.about.bio} />
      <Skills skillCategories={portfolioData.skillCategories} />
      <Projects projects={portfolioData.projects} />
      <Contact contactInfo={portfolioData.contactInfo} />
      <Footer name={portfolioData.name} socialLinks={portfolioData.socialLinks} />
      <Toaster />
    </div>
  );
}
