import { motion } from 'motion/react';
import { Github, Linkedin, Mail } from 'lucide-react';
import { Button } from './ui/button';

interface HeroProps {
  name: string;
  title: string;
  description: string;
  socialLinks: {
    github?: string;
    linkedin?: string;
    email?: string;
  };
}

export function Hero({ name, title, description, socialLinks }: HeroProps) {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center px-4 py-20">
      <div className="max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="mb-4">{name}</h1>
          <h2 className="mb-6 text-muted-foreground">{title}</h2>
          <p className="mb-8 text-muted-foreground max-w-2xl mx-auto">
            {description}
          </p>
          <div className="flex gap-4 justify-center mb-8">
            {socialLinks.github && (
              <Button variant="outline" size="icon" asChild>
                <a href={socialLinks.github} target="_blank" rel="noopener noreferrer">
                  <Github className="h-5 w-5" />
                </a>
              </Button>
            )}
            {socialLinks.linkedin && (
              <Button variant="outline" size="icon" asChild>
                <a href={socialLinks.linkedin} target="_blank" rel="noopener noreferrer">
                  <Linkedin className="h-5 w-5" />
                </a>
              </Button>
            )}
            {socialLinks.email && (
              <Button variant="outline" size="icon" asChild>
                <a href={`mailto:${socialLinks.email}`}>
                  <Mail className="h-5 w-5" />
                </a>
              </Button>
            )}
          </div>
          <div className="flex gap-4 justify-center">
            <Button asChild>
              <a href="#projects">View Projects</a>
            </Button>
            <Button variant="outline" asChild>
              <a href="#contact">Contact Me</a>
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
